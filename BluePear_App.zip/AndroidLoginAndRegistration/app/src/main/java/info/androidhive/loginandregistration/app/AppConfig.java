package info.androidhive.loginandregistration.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "http://47.254.146.113/login.php";

	// Server user register url
	public static String URL_REGISTER = "http://47.254.146.113/register.php";
}
