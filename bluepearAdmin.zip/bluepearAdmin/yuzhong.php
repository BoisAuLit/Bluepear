
    <?php
    session_start();

        $arrext = array('xlsx', 'xls');
        if (!empty($_FILES[up_file][name])) {
            $fileinfo = $_FILES[up_file];
            if ($fileinfo['size'] < 2000000000 && $fileinfo['size'] > 0) {
                move_uploaded_file($fileinfo['tmp_name'], 'upload_dossier/' . $_SESSION[name] . 'zhongzhu.xls');
                //the function for upload the dossier
                echo '上传成功';
                $newfilename = $_SESSION[name] . 'zhongzhu.xls';
            } else {
                echo '文件太大或格式不正确';
            }
        }

 /*  function setexcel($newfilename)
    {
        header("Content-type:text/html;charset=utf-8");   // 设置编码
        require_once './PHPExcel/PHPExcel.php';           // 引入phpexcel文件
        $PHPExcel = \PHPExcel_IOFactory::load('./download_dossier/demo.xls' ); // 加载excel文件
        $currentSheet = $PHPExcel->getSheet(0);           // 第一个sheet
        $col = $currentSheet->getHighestColumn();         // 取得总列数
        $row = $currentSheet->getHighestRow();            // 取得总行数
        $arr = array();
        for ($currentRow = 1; $currentRow <= $row; $currentRow++) {
            for ($currentColumn = 'A'; $currentColumn <= $col; $currentColumn++) {
                $arr[$currentRow][] .= $currentSheet->getCellByColumnAndRow(ord($currentColumn) - 65, $currentRow)->getValue();
            }
        }
      return $arr;
    }

    $filename = $this->upexcel($_FILES['enroll']);

    // 将excel文件里的数据读取出来
    $arr = $this->setexcel($filename);

    // 判断上传的excel文件是否有值
    if(count($arr) <= 0 ){
        unlink($filename);
        $this->error('导入数据为空，请重新上传');
    }

    // 可以直接写入到数据库中了
    $roster = D('table');
    foreach($arr as $v){
        $roster->add($data);
    }
    // excel上传文件
 /*   public function upexcel($file)
    {
        $pubtime1=date("Y-m-d",time());
        $pubtime2=explode("-",$pubtime1);
        $dir = "./uploads/$pubtime2[0]/$pubtime2[1]/$pubtime2[2]/";
        if(!is_dir($dir)){
            mkdir($dir,0777,TRUE);
        }
        // 允许的上传格式
        $arrext = array('xlsx','xls');
        if($file['size'] > 3145728 ) $this->error('文件上传大于3M');
        // 获取上传文件的后缀
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        if(!in_array(strtolower($ext),$arrext)) $this->error('文件类型不正确，正确格式xls/xlsx');
        // 组装文件名称
        $filename = $dir.time().rand(10000,99999).'.'.$ext;
        // 上传文件
        if(move_uploaded_file($file['tmp_name'],$filename)){
            return $filename;
        }else{
            $this->error('文件上传失败');
        }
    }




    $filename = $this->upexcel($_FILES['enroll']);

    // 将excel文件里的数据读取出来
    $arr = $this->setexcel($filename);

    // 判断上传的excel文件是否有值
    if(count($arr) <= 0 ){
        unlink($filename);
        $this->error('导入数据为空，请重新上传');
    }

    // 可以直接写入到数据库中了
    $roster = D('table');
    foreach($arr as $v){
        $roster->add($data);
    }
*/
    ?>


  <!--  <a href="download_dossier/demo.xls">下载excel 模板1</a>  -->






<!--Footer
==========================-->


<!doctype html>
<html lang="en">

<head>
    <title>用户控制台</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendor/linearicons/style.css">
    <link rel="stylesheet" href="assets/vendor/chartist/css/chartist-custom.css">
    <!-- MAIN CSS -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
    <link rel="stylesheet" href="assets/css/demo.css">
    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
    <!-- ICONS -->
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>

<body>
<!-- WRAPPER -->
<?php include("waperdash.php")?>
<!-- END LEFT SIDEBAR -->
<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <a href="download_dossier/doDownLoad.php?filename=demo.xls">下载excel模版</a>




        </div>
            <!-- END OVERVIEW -->

            <div class="row">
                <div class="col-md-6">


                    <table width="385" height="185" border="0" cellpadding="0" cellspacing="0" >
                        <tr>
                            <td width="142" height="80">&nbsp;</td>
                            <td width="174">&nbsp;</td>
                            <td width="69">&nbsp;</td>
                        </tr>
                        <form action="" method="post" enctype="multipart/form-data" name="form1">
                            <tr>
                                <td height="30">&nbsp;</td>
                                <td align="left" valign="middle"><input name="up_file" type="file" size="12" /></td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td height="27" align="right">&nbsp;</td>
                                <td align="center" valign="top">&nbsp;&nbsp;<input type="image" name="imageField" src="images/fg.bmp"></td>
                                <td>&nbsp;</td>
                            </tr>
                        </form>

                        <form action="Rfunction.php" method="post" enctype="multipart/form-data" name="form2">
                            <button >
                                <span>分析</span>
                        </form>
                        <tr>
                            <td height="48">&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                    <!-- RECENT PURCHASES -->
                    <!--  <div class="panel">
                         <div class="panel-heading">
                             <h3 class="panel-title">Recent Purchases</h3>
                             <div class="right">
                                 <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                 <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                             </div>
                         </div>
                         <div class="panel-body no-padding">
                             <table class="table table-striped">
                                 <thead>
                                 <tr>
                                     <th>Order No.</th>
                                     <th>Name</th>
                                     <th>Amount</th>
                                     <th>Date &amp; Time</th>
                                     <th>Status</th>
                                 </tr>
                                 </thead>
                                 <tbody>
                                 <tr>
                                     <td><a href="#">763648</a></td>
                                     <td>Steve</td>
                                     <td>$122</td>
                                     <td>Oct 21, 2016</td>
                                     <td><span class="label label-success">COMPLETED</span></td>
                                 </tr>
                                 <tr>
                                     <td><a href="#">763649</a></td>
                                     <td>Amber</td>
                                     <td>$62</td>
                                     <td>Oct 21, 2016</td>
                                     <td><span class="label label-warning">PENDING</span></td>
                                 </tr>
                                 <tr>
                                     <td><a href="#">763650</a></td>
                                     <td>Michael</td>
                                     <td>$34</td>
                                     <td>Oct 18, 2016</td>
                                     <td><span class="label label-danger">FAILED</span></td>
                                 </tr>
                                 <tr>
                                     <td><a href="#">763651</a></td>
                                     <td>Roger</td>
                                     <td>$186</td>
                                     <td>Oct 17, 2016</td>
                                     <td><span class="label label-success">SUCCESS</span></td>
                                 </tr>
                                 <tr>
                                     <td><a href="#">763652</a></td>
                                     <td>Smith</td>
                                     <td>$362</td>
                                     <td>Oct 16, 2016</td>
                                     <td><span class="label label-success">SUCCESS</span></td>
                                 </tr>
                                 </tbody>
                             </table>
                         </div>
                         <div class="panel-footer">
                             <div class="row">
                                 <div class="col-md-6"><span class="panel-note"><i class="fa fa-clock-o"></i> Last 24 hours</span></div>
                                 <div class="col-md-6 text-right"><a href="#" class="btn btn-primary">View All Purchases</a></div>
                             </div>
                         </div>
                     </div> -->
                    <!-- END RECENT PURCHASES -->
                </div>
                <div class="col-md-6">
                    <!-- MULTI CHARTS -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Projection vs. Realization</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div id="visits-trends-chart" class="ct-chart"></div>
                        </div>
                    </div>
                    <!-- END MULTI CHARTS -->
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <!-- TODO LIST -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">To-Do List</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <ul class="list-unstyled todo-list">
                                <li>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox"><span></span>
                                    </label>
                                    <p>
                                        <span class="title">Restart Server</span>
                                        <span class="short-description">Dynamically integrate client-centric technologies without cooperative resources.</span>
                                        <span class="date">Oct 9, 2016</span>
                                    </p>
                                    <div class="controls">
                                        <a href="#"><i class="icon-software icon-software-pencil"></i></a> <a href="#"><i class="icon-arrows icon-arrows-circle-remove"></i></a>
                                    </div>
                                </li>
                                <li>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox"><span></span>
                                    </label>
                                    <p>
                                        <span class="title">Retest Upload Scenario</span>
                                        <span class="short-description">Compellingly implement clicks-and-mortar relationships without highly efficient metrics.</span>
                                        <span class="date">Oct 23, 2016</span>
                                    </p>
                                    <div class="controls">
                                        <a href="#"><i class="icon-software icon-software-pencil"></i></a> <a href="#"><i class="icon-arrows icon-arrows-circle-remove"></i></a>
                                    </div>
                                </li>
                                <li>
                                    <label class="control-inline fancy-checkbox">
                                        <input type="checkbox"><span></span>
                                    </label>
                                    <p>
                                        <strong>Functional Spec Meeting</strong>
                                        <span class="short-description">Monotonectally formulate client-focused core competencies after parallel web-readiness.</span>
                                        <span class="date">Oct 11, 2016</span>
                                    </p>
                                    <div class="controls">
                                        <a href="#"><i class="icon-software icon-software-pencil"></i></a> <a href="#"><i class="icon-arrows icon-arrows-circle-remove"></i></a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- END TODO LIST -->
                </div>
                <div class="col-md-5">
                    <!-- TIMELINE -->
                    <div class="panel panel-scrolling">
                        <div class="panel-heading">
                            <h3 class="panel-title">Recent User Activity</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <ul class="list-unstyled activity-list">
                                <li>
                                    <img src="assets/img/user1.png" alt="Avatar" class="img-circle pull-left avatar">
                                    <p><a href="#">Michael</a> has achieved 80% of his completed tasks <span class="timestamp">20 minutes ago</span></p>
                                </li>
                                <li>
                                    <img src="assets/img/user2.png" alt="Avatar" class="img-circle pull-left avatar">
                                    <p><a href="#">Daniel</a> has been added as a team member to project <a href="#">System Update</a> <span class="timestamp">Yesterday</span></p>
                                </li>
                                <li>
                                    <img src="assets/img/user3.png" alt="Avatar" class="img-circle pull-left avatar">
                                    <p><a href="#">Martha</a> created a new heatmap view <a href="#">Landing Page</a> <span class="timestamp">2 days ago</span></p>
                                </li>
                                <li>
                                    <img src="assets/img/user4.png" alt="Avatar" class="img-circle pull-left avatar">
                                    <p><a href="#">Jane</a> has completed all of the tasks <span class="timestamp">2 days ago</span></p>
                                </li>
                                <li>
                                    <img src="assets/img/user5.png" alt="Avatar" class="img-circle pull-left avatar">
                                    <p><a href="#">Jason</a> started a discussion about <a href="#">Weekly Meeting</a> <span class="timestamp">3 days ago</span></p>
                                </li>
                            </ul>
                            <button type="button" class="btn btn-primary btn-bottom center-block">Load More</button>
                        </div>
                    </div>
                    <!-- END TIMELINE -->
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <!-- TASKS -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">My Tasks</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <ul class="list-unstyled task-list">
                                <li>
                                    <p>Updating Users Settings <span class="label-percent">23%</span></p>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="23" aria-valuemin="0" aria-valuemax="100" style="width:23%">
                                            <span class="sr-only">23% Complete</span>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <p>Load &amp; Stress Test <span class="label-percent">80%</span></p>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            <span class="sr-only">80% Complete</span>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <p>Data Duplication Check <span class="label-percent">100%</span></p>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                                            <span class="sr-only">Success</span>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <p>Server Check <span class="label-percent">45%</span></p>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
                                            <span class="sr-only">45% Complete</span>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <p>Mobile App Development <span class="label-percent">10%</span></p>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 10%">
                                            <span class="sr-only">10% Complete</span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- END TASKS -->
                </div>
                <div class="col-md-4">
                    <!-- VISIT CHART -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Website Visits</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div id="visits-chart" class="ct-chart"></div>
                        </div>
                    </div>
                    <!-- END VISIT CHART -->
                </div>
                <div class="col-md-4">
                    <!-- REALTIME CHART -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">System Load</h3>
                            <div class="right">
                                <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div id="system-load" class="easy-pie-chart" data-percent="70">
                                <span class="percent">70</span>
                            </div>
                            <h4>CPU Load</h4>
                            <ul class="list-unstyled list-justify">
                                <li>High: <span>95%</span></li>
                                <li>Average: <span>87%</span></li>
                                <li>Low: <span>20%</span></li>
                                <li>Threads: <span>996</span></li>
                                <li>Processes: <span>259</span></li>
                            </ul>
                        </div>
                    </div>
                    <!-- END REALTIME CHART -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->
<div class="clearfix"></div>

</div>
<!-- END WRAPPER -->
<!-- Javascript -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="assets/vendor/chartist/js/chartist.min.js"></script>
<script src="assets/scripts/klorofil-common.js"></script>
<script>
    $(function() {
        var data, options;

        // headline charts
        data = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            series: [
                [23, 29, 24, 40, 25, 24, 35],
                [14, 25, 18, 34, 29, 38, 44],
            ]
        };

        options = {
            height: 300,
            showArea: true,
            showLine: false,
            showPoint: false,
            fullWidth: true,
            axisX: {
                showGrid: false
            },
            lineSmooth: false,
        };

        new Chartist.Line('#headline-chart', data, options);


        // visits trend charts
        data = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            series: [{
                name: 'series-real',
                data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
            }, {
                name: 'series-projection',
                data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
            }]
        };

        options = {
            fullWidth: true,
            lineSmooth: false,
            height: "270px",
            low: 0,
            high: 'auto',
            series: {
                'series-projection': {
                    showArea: true,
                    showPoint: false,
                    showLine: false
                },
            },
            axisX: {
                showGrid: false,

            },
            axisY: {
                showGrid: false,
                onlyInteger: true,
                offset: 0,
            },
            chartPadding: {
                left: 20,
                right: 20
            }
        };

        new Chartist.Line('#visits-trends-chart', data, options);


        // visits chart
        data = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            series: [
                [6384, 6342, 5437, 2764, 3958, 5068, 7654]
            ]
        };

        options = {
            height: 300,
            axisX: {
                showGrid: false
            },
        };

        new Chartist.Bar('#visits-chart', data, options);


        // real-time pie chart
        var sysLoad = $('#system-load').easyPieChart({
            size: 130,
            barColor: function(percent) {
                return "rgb(" + Math.round(200 * percent / 100) + ", " + Math.round(200 * (1.1 - percent / 100)) + ", 0)";
            },
            trackColor: 'rgba(245, 245, 245, 0.8)',
            scaleColor: false,
            lineWidth: 5,
            lineCap: "square",
            animate: 800
        });

        var updateInterval = 3000; // in milliseconds

        setInterval(function() {
            var randomVal;
            randomVal = getRandomInt(0, 100);

            sysLoad.data('easyPieChart').update(randomVal);
            sysLoad.find('.percent').text(randomVal);
        }, updateInterval);

        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

    });
</script>
</body>
<?php include("footdashboard.php")?>
</html>