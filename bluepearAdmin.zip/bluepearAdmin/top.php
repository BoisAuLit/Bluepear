
<!-- * Created by PhpStorm.
 * User: yujie
 * Date: 19/07/2017
 * Time: 11:19
 */-->
<?php
session_start();
?>

<div id="header-row">
    <div class="container">
        <div class="row">
            <!--LOGO-->
            <div class="span3"><a class="brand" href="#"><img src="img/logo2.png"  style="margin-left:20px; width:280px ; height:85px; "/></a></div>
            <!-- /LOGO -->

            <!-- MAIN NAVIGATION --
            <div class="span9">
                <div class="navbar  pull-right">
                    <div class="navbar-inner">
                        <a data-target=".navbar-responsive-collapse" data-toggle="collapse" class="btn btn-navbar"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a>
                        <div class="nav-collapse collapse navbar-responsive-collapse">
                                      <ul class="nav">
                                <li class="active"><a href="index.php">首页</a></li>


                                <li><a href="about.php">关于我们</a></li>
                                <li class="dropdown">
                                    <a  class="dropdown-toggle" data-toggle="dropdown">功能<b class="caret"></b></a>

                                    <ul class="dropdown-menu">

                                    <?php if ($_SESSION[name]==""){
                                        echo "<li><a href=''>遗传评估</a></li>
                                        <li><a href=''>智能兽医</a></li>
                                        <li><a href=''>饲料配置</a></li>";}
                                        else{
                                        echo "
                                       <li><a href='dashboard.php'>遗传评估</a></li>
                                        <li><a href='dashboard.php'>智能兽医</a></li>
                                        <li><a href='dashboard.php'>饲料配置</a></li>";}
                                        ?>
                                    </ul>

                                </li>


                                <li><a href="register.php">登录</a></li>
                                <li><a href="contact.php">联系我们</a></li>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
          MAIN NAVIGATION -->
        </div>
    </div>
</div>

