<?php
/**
 * Created by PhpStorm.
 * User: yujie
 * Date: 28/07/2017
 * Time: 17:12
 */?>
<footer>
    <div class="container-fluid">
        <p class="copyright">&copy; 2017 <a href="#" target="_blank">Theme I Need</a>. All Rights Reserved. </p>
    </div>
</footer>
