<!--
/**
 * Created by PhpStorm.
 * User: yujie
 * Date: 19/07/2017
 * Time: 11:26-->
<footer>
    <div class="container">
        <div class="row">
            <div class="span6">Copyright @copy2013 Shapebootstrap | All Rights Reserved  More Templates <a href="http://www.cssmoban.com/" target="_blank" title="bootstrap"></a><br>

            </div>
            <div class="span6">
                <div class="social pull-right">
                    <a href="#"><img src="img/social/googleplus.png" alt=""></a>
                    <a href="#"><img src="img/social/dribbble.png" alt=""></a>
                    <a href="#"><img src="img/social/twitter.png" alt=""></a>
                    <a href="#"><img src="img/social/dribbble.png" alt=""></a>
                    <a href="#"><img src="img/social/rss.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</footer>