
<head>

<meta charset="utf-8">
</head>

<?php
session_start();
$name=$_POST[username];          //接收表单提交的用户名
$pwd=$_POST[userpsw];            //接收表单提交的密码
$lifeTime=10*3600;

 class chkinput{                //定义类
    public $name;
    public $pwd;

    function chkinput($x,$y){
        $this->name=$x;
        $this->pwd=$y;
    }

    function checkinput(){


       include("db/database.php");   		  //连接数据源
       $query="SELECT * FROM admin where nom='".$this->name."' and password='".$this->pwd."'";
       $result = $conn->query($query);

       $info=mysqli_fetch_array($result);       //名称和密码是否正确

          //检索用户名称和密码是否正确
        if($info==false){                    //如果名称或密码不正确，则弹出相关提示信息
            echo "<script language='javascript'>alert('您输入的用户名称或密码错误，请重新输入！');history.back();</script>";
            exit;
        }
        else{
            $_SESSION[name] =$this->name;
            $_SESSION[pwd]=$this->pwd;

            echo "<script>alert('réussir!');window.location='dashboard.php';</script>";//如果名称或密码正确，则弹出相关提示信息

        }

    }


}




$obj=new chkinput(trim($name),trim($pwd));      //创建对象

$obj->checkinput();          				    //调用类*/



?>