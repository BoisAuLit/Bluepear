<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>ShapeBootstrap Clean Template</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  <![endif]-->

  <!-- Fav and touch icons -->
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  <link rel="shortcut icon" href="img/favicon.png">
  


    <!-- SCRIPT 
    ============================================================-->  
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>


  <!--HEADER ROW-->
  <div id="header-row">
    <div class="container">
      <div class="row">
              <!--LOGO-->
              <div class="span3"><a class="brand" href="#"><img src="img/logo.png"/></a></div>
              <!-- /LOGO -->

            <!-- MAIN NAVIGATION -->  
              <div class="span9">
                <div class="navbar  pull-right">
                  <div class="navbar-inner">
                    <a data-target=".navbar-responsive-collapse" data-toggle="collapse" class="btn btn-navbar"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a>
                    <div class="nav-collapse collapse navbar-responsive-collapse">
                    <ul class="nav">
                        <li class="active"><a href="index.html">Home</a></li>
                        
                        <li class="dropdown">
                          <a href="about.html" class="dropdown-toggle" data-toggle="dropdown">About <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                  <li><a href="about.html">Company</a></li>
                                  <li><a href="about.html">History</a></li>
                                  <li><a href="about.html">Team</a></li>
                            </ul>

                        </li>

                        <li><a href="service.html">Services</a></li>
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="contact.html">Contact</a></li>
                 
                    </ul>
                  </div>

                  </div>
                </div>
              </div>
            <!-- MAIN NAVIGATION -->  
      </div>
    </div>
  </div>
  <!-- /HEADER ROW -->




<div class="container">
	  <!--PAGE TITLE-->

	<div class="row">
		<div class="span12">
		<div class="page-header">
				<h1>
				Services
			</h1>
		</div>
		</div>
	</div>

  <!-- /. PAGE TITLE-->

	<div class="row">
		<div class="span6">
		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service1.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.	
					</p>
					<a href="#" class="btn" type="button">Button</a>


				</div>
			</div>
		</div>			


		<div class="span6">

		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service2.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
					</p>
					<a href="#" class="btn" type="button">Button</a>
				</div>
			</div>
		</div>

		<div class="span6">
		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service3.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>
					Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
					</p>
					<a href="#" class="btn" type="button">Button</a>
				</div>
			</div>
		</div>


		
		<div class="span6">
		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service4.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>
					Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
					</p>
					<a href="#" class="btn" type="button">Button</a>
				</div>
			</div>


		</div>		

		<div class="span6">
		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service5.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>
					Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
					</p>
					<a href="#" class="btn" type="button">Button</a>
				</div>
			</div>


		</div>		

		<div class="span6">
		<div class="media">
				 <a href="#" class="pull-left"><img src="img/icon-service6.png" class="media-object" alt='' /></a>
				<div class="media-body">
					<h4 class="media-heading">
						Nested media heading
					</h4> 
					<p>
					Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
					</p>
					<a href="#" class="btn" type="button">Button</a>
				</div>
			</div>


		</div>

	</div>
</div>



<!--Footer
==========================-->

<footer>
    <div class="container">
      <div class="row">
        <div class="span6">Copyright &copy 2013 Shapebootstrap | All Rights Reserved  <br>
        <small>Aliquam tincidunt mauris eu risus.</small>
        </div>
        <div class="span6">
            <div class="social pull-right">
                <a href="#"><img src="img/social/googleplus.png" alt=""></a>
                <a href="#"><img src="img/social/dribbble.png" alt=""></a>
                <a href="#"><img src="img/social/twitter.png" alt=""></a>
                <a href="#"><img src="img/social/dribbble.png" alt=""></a>
                <a href="#"><img src="img/social/rss.png" alt=""></a>
            </div>
        </div>
      </div>
    </div>
</footer>

<!--/.Footer-->

</body>
</html>
