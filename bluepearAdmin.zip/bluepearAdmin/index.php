



<!DOCTYPE html>
<html lang="zh-cn">
<link rel="shortcut icon" href="img/logo.png">
<!-- SCRIPT
 ============================================================-->
<script src="http://code.jquery.com/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>
    </title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">

    <link href="css/styleres.css" rel="stylesheet">

</head>

<body>

<script language="javascript" >





    function check1(form){
        if(form.username.value==""){
            alert("merci de saisir voter nom.");form.user.focus();return false;
        }
        if(form.userpsw.value==""){
            alert("merci de saisir voter mot de pass.");form.userpsw.focus();return false;
        }
        form.submit();
    }

</script>


<!--head-->
<?php include("top.php")?>


<div class="container">
    <div class="sign-page">
        <div class="alert alert-info" role="alert">

        </div>
        <div class="signup-page">




  			<h3>Our groupe</h3>
  			<address>
  <strong>Bluepear,EFREI.</strong><br>
                30-32 Avenue de la République<br>
  villejuif, FR 94800<br>
  <abbr title="Phone">tel: (+33) 658283385</abbr>
</address>

<address>
  <strong>Email:</strong><br>
  <a href="mailto:#">blue.pear@efrei.com</a>
</address>

  			<p>
If you have any question, please contact us. We will give you the best solution at the first time


  			</p>

        </div>
        <div class="signin-page">
            <form name="form1" method="post" action="chklogin.php">
                <h3>
                   Login
                </h3>
                <p class="slogan">
                   Administration
                </p>
                <div class="input-prepend">
                    <span class="glyphicon glyphicon-user"></span>
                    <input type="text" placeholder="用户名" name="username" id="user1">
                </div>
                <br>
                <div class="input-prepend">
                    <span class="glyphicon glyphicon-lock"></span>
                    <input type="password" placeholder="******" name="userpsw" id="psw1">
                </div>
                <br>
                <span id="control-group">
              <label>
                <input type="checkbox" value="option1">
                remember me
              </label>
              <a href="/user/newpasswd">forget the password?</a>
            </span>
                <br>
                <button name="submit" type="submit" class="btn btn-lg btn-danger btn-block" onClick="return check1(form1)">
                    <span>login</span>
                </button>
            </form>
        </div>
    </div>
</div>
</body>


<?php include("bottom.php")?>
</html>


