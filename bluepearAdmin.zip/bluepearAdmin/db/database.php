<?php
$host="127.0.0.1";
$user="root";
$password="19881208";
$database = "bluepear";
$conn = new mysqli($host, $user, $password, $database);


if($conn->connect_errno > 0){
    die('Unable to connect to database [' . $conn->connect_error . ']');
}
?>